'use strict';


angular.module("myApp.view1", []);

var myAppView1 = angular.module("myApp.view1", ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view1', {
    templateUrl: 'view1/view1.html',
    controller: 'View1Ctrl'
  });
}])

.controller('View1Ctrl', ['$scope','$http',function($scope, $http) {
    $scope.details = {
        phone: null,
        combinationsResponse: null,
        combinations: null,
        combinationsLength:null

    };
   $scope.getCombinations = function() {
        console.log($scope.details.phone);
       var request = $http({
           method: "get",
           url: "http://localhost:8080/Numbercombinations/combinations/getCombinations?phoneNumber="+$scope.details.phone,
           data: '',
           headers: {
               "Content-Type": "application/json"
           },
       });
       console.log(request);
       console.log(request.then( handleSuccess, handleError ));
   };

    function handleError( response ) {

        return( "error" );
    }
    // Transform the successful response, unwrapping the application data from the API response payload.
    function handleSuccess( response ) {
        console.log("Final"+JSON.stringify(response.data));
        $scope.details.combinationsResponse =  response.data;
        $scope.details.combinations = response.data.combinations;
        $scope.details.combinationsLength = $scope.details.combinations.length();
        return( response.data );
    }
}]);

